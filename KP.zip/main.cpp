#include <iostream>
#include <stdio.h>
#include <stdlib.h>
using namespace std; 

int main()
{

  int n, i, j;
  int x2,x3,x5,x7, s, st;
  printf("Unesite koliko brojeva želite da kriptujete: ");
  scanf("%d", &n);
  int a[n], b[n], t[100], br;
  printf("Unesite brojeve koje želite da kriptujete: ");
  
  for (i=0; i<n; i++)
  {
    scanf("%d", &a[i]);
  }
  x2 = 3;
  x3 = 3;
  x5 = -1;
  x7 = 3;
  j = 0;
  
  for (i = 0; i < n; i++)
  {
    st = 0;
    br = 0;
    printf ("broj : %d, ", a[i]);
    
    //PRVI KRUG
    t[br] = 0;
    if (a[i] % 2 == 0)
    {
      a[i] = a[i] + x2;
      t[br] = x2; 
      x2 = x2 + 3;
      if (x2 > 9)
      {
       x2 = 3;
      }
    } 
    br++;
    
    t[br] = 0;
    if(a[i] % 3 == 0)
    {
      a[i] = a[i] + x3;
      t[br] = x3;
      x3 = x3 + 2;
      if(x3 > 9)
      {
         x3 = 3;
      }
    } 
    br++;

    t[br] = 0;
    if(a[i] % 5 == 0)
    {
      a[i] = a[i] + x5;
      t[br] = x5;
      x5 = x5 -1;
      if (x5 < -3)
      {
        x5 = 1;
      }
    }
    br++;

    t[br] = 0;
    if(a[i] % 7 == 0)
    {
      a[i] = a[i] + x7;
      t[br] = x7;
      x7 = x7 + 3;
      if (x7 > 9)
      {
        x7 = 3;
      }
    }
    br++;

    //DRUGI KRUG

    if (a[i] % 2 == 0)
    {
     a[i] = a[i] - 7;
     s = 0;
    }
    else 
    {
     a[i] = a[i] - 6;
     s = 1;
    }
    
    // TRECI KRUG 
    if (a[i] < 0)
    {
     a[i] = a[i]*2 + 10 - 1;
     st = 1;
    }
    
    //CETVRTI KRUG
        t[br] = 0;
    if (a[i] % 2 == 0)
    {
      a[i] = a[i] + x2;
      t[br] = x2;
      x2 = x2 + 3;
      if (x2 > 9)
      {
       x2 = 3;
      }
    } 
    br++;

    t[br] = 0;
    if(a[i] % 3 == 0)
    {
      a[i] = a[i] + x3;
      t[br] = x3;    
      x3 = x3 + 2;
      if(x3 > 9)
      {
         x3 = 3;
      }
    } 
    br++;

    t[br] = 0;
    if(a[i] % 5 == 0)
    {
      a[i] = a[i] + x5;
      t[br] = x5;
      x5 = x5 -1;
      if (x5 < -3)
      {
        x5 = 1;
      }
    }
    br++;

    t[br] = 0;
    if(a[i] % 7 == 0)
    {
      a[i] = a[i] + x7;
      t[br] = x7;
      x7 = x7 + 3;
      if (x7 > 9)
      {
        x7 = 3;
      }
    }
    br++;
    
    b[j] = a[i]; // PRVI DEO ZA DEKODER


    //PETI KRUG 
    a[i] = a[i] >> 1;
    
    
    
    //DRUGI DEO ZA DEKODER
    for (int k = br - 1; k >= br/2; k--)
    {
      b[j] = b[j] - t[k];
    }

    //TRECI DEO ZA DEKODER
    if(st == 1)
    {
      b[j] = (b[j] + 1 - 10)/2;
    }
    else 
    {
      b[j] = b[j];
    }
  
    //CETVRTI DEO ZA DEKODER
    if(s == 0)
     b[j] = b[j] + 7;
    else 
      b[j] = b[j] + 6;
  
    //PETI DEO ZA DEKODER

    for (int k = br/2 -1 ; k >= 0; k--)
    {
      b[j] = b[j] - t[k];
    }
  
    printf ("kriptovan : %d, ", a[i]);
    printf ("original : %d",  b[j]);
    printf ("\n");
  }

}